import PrimePowerReindexBounded
import NativeZetaLogDerivativeBoundedMoebius

/-!
Candidate exact bridge from the prime Euler series to the logarithmic derivative
of actual zeta. This directly composes two source candidates; the proof requires
external compilation, theorem-level axiom audit, and dependency tracing.
-/

noncomputable section

namespace HVRNativeEulerPrimeZetaBridgeBoundedMoebius

theorem eulerProductLogDerivative : HVRNativeZetaLogDerivative.EulerProductLogDerivative := by
  intro s hs
  exact (HVRPrimePowerReindexBounded.primePowerReindexing s hs).symm.trans
    (HVRNativeZetaLogDerivativeBoundedMoebius.vonMangoldt_LSeries_eq_neg_logDeriv_zeta hs)

end HVRNativeEulerPrimeZetaBridgeBoundedMoebius

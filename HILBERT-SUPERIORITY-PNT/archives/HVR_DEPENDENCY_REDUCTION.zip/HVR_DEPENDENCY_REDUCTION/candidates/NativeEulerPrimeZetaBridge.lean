import PrimePowerReindexBounded
import NativeZetaLogDerivativeConvolution

/-!
Candidate exact bridge from the prime Euler series to the logarithmic derivative
of actual zeta. This directly composes two source candidates; the proof requires
external compilation, theorem-level axiom audit, and dependency tracing.
-/

noncomputable section

namespace HVRNativeEulerPrimeZetaBridge

theorem eulerProductLogDerivative : HVRNativeZetaLogDerivative.EulerProductLogDerivative := by
  intro s hs
  exact (HVRPrimePowerReindexBounded.primePowerReindexing s hs).symm.trans
    (HVRNativeZetaLogDerivativeConvolution.vonMangoldt_LSeries_eq_neg_logDeriv_zeta hs)

end HVRNativeEulerPrimeZetaBridge

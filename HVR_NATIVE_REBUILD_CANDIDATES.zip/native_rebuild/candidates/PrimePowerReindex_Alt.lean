import NativeSummabilityUnified
import NativeMangoldtPrime
import NativeMangoldtPow
import NativeZetaLogDerivative
import Mathlib.NumberTheory.EulerProduct.Basic
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.SpecialFunctions.Pow.Complex
import Mathlib.Tactic

/-!
Direct prime-power reindexing candidate.

This is an uncompiled candidate. It reindexes the entire von Mangoldt
L-series term using Mathlib's generic support-on-prime-powers theorem, then
sums each prime's positive-power geometric series. It does not invoke the
zeta logarithmic-derivative theorem. It does use Mathlib's general infinite
sum reindexing and elementary complex-power infrastructure. Its dependency
graph, compilation, and theorem-level axiom audit must be checked externally.
-/

noncomputable section

namespace HVRPrimePowerReindexAlt

open HVRNativeZetaLogDerivative

def coeff (n : ℕ) : ℂ := (ArithmeticFunction.vonMangoldt n : ℂ)

theorem coeff_zero : coeff 0 = 0 := by
  simp [coeff]

/-- The actual von Mangoldt series term is supported on prime powers. -/
theorem term_support (s : ℂ) :
    Function.support (LSeries.term coeff s) ⊆ {n : ℕ | IsPrimePow n} := by
  intro n hn
  by_contra hp
  apply hn
  simp [LSeries.term_def₀ coeff_zero, coeff, ArithmeticFunction.vonMangoldt_apply, hp]

/-- Powers of a natural prime commute with the complex exponent in this case. -/
theorem prime_power_cpow (p m : ℕ) (s : ℂ) :
    (((p ^ m : ℕ) : ℂ) ^ (-s)) = ((p : ℂ) ^ (-s)) ^ m := by
  calc
    (((p ^ m : ℕ) : ℂ) ^ (-s)) = ((p : ℂ) ^ m) ^ (-s) := by rw [Nat.cast_pow]
    _ = (p : ℂ) ^ ((m : ℂ) * (-s)) :=
      (Complex.natCast_cpow_natCast_mul p m (-s)).symm
    _ = ((p : ℂ) ^ (-s)) ^ m := Complex.cpow_nat_mul (p : ℂ) m (-s)

/-- The spectral ratio has modulus less than one for each actual prime. -/
theorem prime_ratio_lt_one (p : Nat.Primes) (s : ℂ) (hs : 1 < s.re) :
    ‖((p : ℕ) : ℂ) ^ (-s)‖ < 1 := by
  have hpzero : ((p : ℕ) : ℂ) ≠ 0 := by exact_mod_cast p.property.ne_zero
  have hpone : (1 : ℝ) < ((p : ℕ) : ℝ) := by exact_mod_cast p.property.one_lt
  have hlog : 0 < Real.log ((p : ℕ) : ℝ) := Real.log_pos hpone
  rw [Complex.cpow_def_of_ne_zero hpzero]
  have hlogcast : Complex.log ((p : ℕ) : ℂ) =
      (Real.log ((p : ℕ) : ℝ) : ℂ) := by
    simpa using (Complex.ofReal_log (le_of_lt (lt_trans zero_lt_one hpone))).symm
  rw [hlogcast, Complex.norm_exp]
  simp only [Complex.mul_re, Complex.neg_re, Complex.neg_im,
    Complex.ofReal_re, Complex.ofReal_im, mul_zero, sub_zero]
  apply Real.exp_lt_one_iff.mpr
  have hsr : 0 < s.re := lt_trans zero_lt_one hs
  nlinarith [mul_pos hsr hlog]

/-- Evaluation of the positive prime-power series for a fixed prime. -/
theorem prime_power_series (p : Nat.Primes) (s : ℂ) (hs : 1 < s.re) :
    (∑' k : ℕ, LSeries.term coeff s ((p : ℕ) ^ (k + 1))) =
      primeEulerTerm s p := by
  let q : ℂ := ((p : ℕ) : ℂ) ^ (-s)
  let a : ℂ := (Real.log ((p : ℕ) : ℝ) : ℂ)
  have hq : ‖q‖ < 1 := prime_ratio_lt_one p s hs
  have hgeom := (hasSum_geometric_of_norm_lt_one hq).mul_left (a * q)
  have hfun :
      (fun k : ℕ => LSeries.term coeff s ((p : ℕ) ^ (k + 1))) =
        (fun k : ℕ => (a * q) * q ^ k) := by
    funext k
    rw [LSeries.term_def₀ coeff_zero]
    have hk : k + 1 ≠ 0 := by omega
    simp only [coeff, HVRNativeMangoldtPow.vonMangoldt_apply_pow_native hk,
      HVRNativeMangoldtPrime.vonMangoldt_apply_prime_native p.property]
    rw [prime_power_cpow]
    dsimp only [a, q]
    rw [pow_succ]
    ring
  rw [hfun]
  have hsum : (∑' k : ℕ, (a * q) * q ^ k) = (a * q) * (1 - q)⁻¹ := hgeom.tsum_eq
  rw [hsum]
  dsimp only [a, q, primeEulerTerm]
  simp only [div_eq_mul_inv]
  ring

/-- Candidate for the actual prime-power reindexing premise, Re(s)>1. -/
theorem primePowerReindexing : PrimePowerReindexing := by
  intro s hs
  have hsum : Summable (LSeries.term coeff s) := by
    exact HVRNativeSummabilityUnified.vonMangoldt_lseries_summable hs
  have heq := tsum_eq_tsum_primes_of_support_subset_prime_powers hsum (term_support s)
  change (∑' n : ℕ, LSeries.term coeff s n) = primeEulerSeries s
  rw [heq]
  unfold primeEulerSeries
  apply tsum_congr
  intro p
  exact prime_power_series p s hs

end HVRPrimePowerReindexAlt
